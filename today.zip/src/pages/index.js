import React, { Component } from 'react'
import MiniDrawer from '../components/Layout'
import Tables from '../components/Tables'
import Grid from '@material-ui/core/Grid'
import axios from 'axios'
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import Tab from '../components/Tab'
import MuiThemeProvider from "@material-ui/core/styles/MuiThemeProvider";
import { createMuiTheme } from "@material-ui/core/styles";

const theme = createMuiTheme({
    typography: {
      // Use the system font instead of the default Roboto font.
      fontFamily: [
        'Helvetica'
      ].join(','),
    },
  });
  

class Home extends Component {
    constructor(props){
        super(props)
       
        this.state = {
            thotsakanTickets : [],
            otherTickets : [],
            currentTickets:[],
            currentState : 1,
        }
        this.setCurrentTickets = this.setCurrentTickets.bind(this);
        this.updateTicket = this.updateTicket.bind(this);
    }

   /* setThontsakan(){
        if(this.state.currentState == 1){
            this.setCurrentTickets(this.state.thotsakanTickets,1)
        }
    }
    setOther(){

    }*/

    setCurrentTickets(ticket,state){
        this.setState({
            currentTickets : ticket
        })
        this.setState({
            currentState : state
        })
    }    


    componentDidMount(){
        axios.get(`https://ticket/api/workorder/group/Upstream SAP`, {
            withCredentials: true } )
            .then(res => {
              this.setState({ 
                  thotsakanTickets : res.data,
                });
                if(this.state.currentState === 1){
                    this.setCurrentTickets(this.state.thotsakanTickets,1)
                }
            })
            
            axios.get(`https://ticket/api/incident/group/Upstream SAP`, {
            withCredentials: true } )
            .then(res => {
              const otherTickets = res.data;
              this.setState({ otherTickets });
              if(this.state.currentState === 2){
                this.setCurrentTickets(otherTickets,2)
              }
            })
            setInterval(this.updateTicket, 600000);
    }



    updateTicket(){
        console.log("update")
        this.setState({ thotsakanTickets : []});
        this.setState({ otherTickets : []});
        this.setState({ currentTickets : []});
    
        axios.get(`https://ticket/api/workorder/group/Upstream SAP`, {
            withCredentials: true } )
            .then(res => {
              this.setState({ 
                  thotsakanTickets : res.data,
                });
            if(this.state.currentState === 1){
                this.setCurrentTickets(this.state.thotsakanTickets,1)
            }
            })
            
        axios.get(`https://ticket/api/incident/group/Upstream SAP`, {
            withCredentials: true } )
            .then(res => {
             const otherTickets = res.data;
            this.setState({ otherTickets });
            if(this.state.currentState === 2){
                this.setCurrentTickets(otherTickets,2)
              }
            })

        }

    render() {  
        return (
            <MuiThemeProvider theme={theme}>
            <MiniDrawer>
                <Grid container spacing={2}>
                    <Grid item sm={12}>
                        <Tab setCurrentTickets={this.setCurrentTickets} state = {this.state}/>  
                        {  this.state.currentTickets.length == 0 ? (<CircularProgress disableShrink style ={{width :"100px" ,height :"100px",marginLeft :"720px",marginTop:"360px"}} />):(  <Tables  currentTickets={this.state.currentTickets}/>)}
                      
                    </Grid>
                </Grid>
            </MiniDrawer>
            </MuiThemeProvider>
        )
    }
}

export default Home