import React, { Component } from 'react'
import MUIDataTable from "./mTable/MUIDataTable";
import {createMuiTheme, MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid'
export default class Tables extends Component {
  /*getMuiTheme = () => createMuiTheme({
    overrides: {
      MUIDataTableHeadCell: {
        Root: {
          //backgroundColor: "#FF0000"
        }
      }
    }
  })*/
  constructor(props){
    super(props)

    this.state = {
      tickets : this.props.currentTickets,
      incidentFilter: [],
      unassignedFilter:[],
      workOrderFilter:[],
      jobFailureFilter:[]
    }
    this.handleIncident = this.handleIncident.bind(this)
    this.handleUnassigne =this.handleUnassigne.bind(this)
    this.handleWorkOrder = this.handleWorkOrder.bind(this)
    this.handleJobFailure =this.handleJobFailure.bind(this)
}
setZero(){
  this.setState({
    typeFilter: [],
    unassignedFilter: [],
    jobFailureFilter: []
  })
}
handleIncident(){
  this.setZero()
  this.setState({
    typeFilter: ['INCIDENT']
  })
}
handleUnassigne(){
  this.setZero()
  this.setState({
    unassignedFilter: ['Unassigned']
  })
}

handleWorkOrder(){
  this.setZero()
  this.setState({
    typeFilter: ['WORKORDER']
  })
}

handleJobFailure(){
  this.setZero()
  this.setState({
    jobFailureFilter: ['JOB FAILURE']
  })
}
  render() {
    const columns = [
      {
       name: "Ticket",
       label: "Ticket",
       options: {
        filterList: this.state.typeFilter,
        filterOptions: {
          names: ["INCIDENT", "WORKORDER", "TASK"],
          logic(type, filters) {
            const show = (filters.indexOf("INCIDENT") >= 0 && type.includes("INC")) ||
              (filters.indexOf("WORKORDER") >= 0 && type.includes("WO")) ||
              (filters.indexOf("TASK") >= 0 && type.includes("TA"))
            const filtered = !show;
            return filtered;
          },
        sort: true,
       }
      }
    },
      {
       name: "Summary",
       label: "Summary",
       options: {
        filterList: this.state.jobFailureFilter,
        filterOptions: {
          names: ["JOB FAILURE"],
          logic(summary, filters) {
            const show = (filters.indexOf("JOB FAILURE") >= 0 && (summary.includes("UC4") || summary.toUpperCase().includes("Job Failure".toUpperCase()))) 
            const filtered = !show;
            return filtered;
          },
        sort: true,
       }
      }
      },
      {
       name: "Status",
       label: "Status",
       options: {
        filter: true,
        sort: false,
        display : false,
       }
      },
      {
       name: "CustomerName",
       label: "CustomerName",
       options: {
        filter: false,
        sort: false,
       }
      },
      {
        name: "Region",
        label: "Region",
        options: {
          filterOptions: {
            names: ["AP", "NA", "EU","SA","AF"],
            logic(region, filters) {
              const show = (filters.indexOf("AP") >= 0 && region == "Asia Pacific" ) ||
                (filters.indexOf("NA") >= 0 && region == "North America") ||
                (filters.indexOf("EU") >= 0 && region == "Europe" ) ||
                (filters.indexOf("SA") >= 0 && region == "Central & South America") ||
                (filters.indexOf("AF") >= 0 && region == "Middle East / Africa" ) 
              const filtered = !show;
              return filtered;
            },
        },
      },
    },
    {
      name: "Assignee",
      label: "Assignee",
      options: {
        sort: false,
        filterList: this.state.unassignedFilter,
        filterOptions: {
          names: ["Unassigned"],
          logic(assignee, filters) {
            const show = (filters.indexOf("Unassigned") >= 0 && !assignee) 
            const filtered = !show;
            return filtered;
          },
      }
    }
     },
     {
      name: "Priority",
      label: "Priority",
      options: {
       filter: false,
       sort: true,
      }
     },
     {
      name: "Product",
      label: "Product",
      options: {
       filter: true,
       sort: false,
      }
     },
     {
      name: "Submit_Date",
      label: "Submit_Date",
      options: {
       filter: false,
       sort: true,
      }
     },
     {
      name: "Last_Modified_Date",
      label: "Last_Modified_Date",
      options: {
       filter: false,
       sort: true,
      }
     },
    
     ];
    let data =[]
    this.props.currentTickets.map((item,i)=>{
      data.push([(item.Work_Order_ID)? item.Work_Order_ID :item.Incident_Number,
        item.Summary,
        item.Status,
        item.Customer.Name,
        item.Customer.Region,
        item.Assignee.Name,
        item.Priority,
        item.Product.Name,
        item.Submit_Date,
        item.Last_Modified_Date])
    })
    const options = {
      filterType: 'multiselect',
      onRowClick : (rowData, rowMeta)=>{
        var url = "http://itconsole/#/"+rowData[0]
        var win = window.open(url, '_blank');
        win.focus();
      }
    };
    return (
      <div>
      <Grid container spacing={3} style={{margin:"20px"}}>
          <Grid item xs={2} >
             <Button variant="contained"color="primary"onClick = {this.handleUnassigne}  style={{height:"60px"}}>Unassined</Button>
          </Grid>
          <Grid item xs={2}>
              <Button variant="contained"color="primary" onClick = {this.handleIncident}  style={{height:"60px"}} >Incident</Button>
            </Grid>
          <Grid item xs={2}>
             <Button variant="contained"color="primary" onClick = {this.handleWorkOrder}  style={{height:"60px"}} >Work Orders</Button>
          </Grid>
          <Grid item xs={2}>
            <Button variant="contained"color="primary" onClick = {this.handleJobFailure}  style={{height:"60px"}} >Job Failure</Button>
          </Grid>
        </Grid>
      <MUIDataTable 
          title={"Open Ticket List"}
          data={data}
          columns={columns}
          options={options}
        />
      </div>

    )
  }
}
