import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
}));

export default function SimpleTabs(props) {
  const classes = useStyles();
  const [value, setValue] = React.useState(0);
  const {setCurrentTickets} = props
  const {thotsakanTickets,scrumblersTickets,superNovaPolarisTickets,globalTickets,otherTickets} = props.state
  
  function handleChange(event, newValue) {
    console.log(newValue)
    if(newValue == 0){
        setCurrentTickets(thotsakanTickets,1)
    }else if (newValue == 1){
        setCurrentTickets(scrumblersTickets,2)
    }else if(newValue == 2){
      setCurrentTickets(superNovaPolarisTickets,3)
    }else if(newValue == 3){
      setCurrentTickets(globalTickets,4)
    }else if (newValue == 4){
      setCurrentTickets(otherTickets, 5)
    }

    setValue(newValue);
  }

  return (
        <Tabs value={value} onChange={handleChange}>
          <Tab label="THOTSAKAN" style={{fontSize:"24px"}}/>
          <Tab label="SCRUMBLERS" style={{fontSize:"24px"}}/>
          <Tab label="SUPERNOVA/POLARIS" style={{fontSize:"24px"}}/>
          <Tab label='GLOBAL' style={{fontSize:'24px'}} />
          <Tab label="OTHERS" style={{fontSize:"24px"}}/>
	<Tab label="ALL" style={{fontSize:"24px"}}/>
        </Tabs>
  );
}