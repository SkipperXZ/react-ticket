import React from 'react';
import clsx from 'clsx';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import SettingIcon from '@material-ui/icons/Settings';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import GroupIcon from '@material-ui/icons/Group';
import Profile from './Profile';
import Grid from '@material-ui/core/Grid'
import DispatcherDialog from './/DispatcherDialog'
import { Search, Notifications, Settings  } from '@material-ui/icons';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import TextField from '@material-ui/core/TextField';
import Switch from '@material-ui/core/Switch';
import FeedBack from '../components/Feedback'

const drawerWidth = 280;



const useStyles = makeStyles(theme => ({
  root: {
    display: 'flex', 
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    color:"white",
    width: 200,
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  }, heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
    color: 'white',
  },
  teamDispactherHeading: {
    fontSize: theme.typography.pxToRem(12),
    fontWeight: theme.typography.fontWeightRegular,
    color:"#42a5f5",
  },
  teamDispactherContent: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
    color: 'white',
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: 36,
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    backgroundColor: '#4A525F',
    color: 'white'
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9) + 1,
    },
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: '0 8px',
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
  svgThemeBlack: {
    color: 'white'
  },
  textRight:{
    textAlign: 'right'
  }
}));

export default function MiniDrawer(props) {
  const classes = useStyles();
  const theme = useTheme();
  const [open, setOpen] = React.useState(true);
  const children = props.children;
  const [values, setValues] = React.useState({
    interval: 3,
  });
  const [state, setState] = React.useState({
    checkedA: false,
  });

  const handleChange = name => event => {
    setValues({ ...values, [name]: event.target.value });
    props.setUpdateInterval(event.target.value)
  };
  const handleToggle = name => event => {
    setState({ ...state, [name]: event.target.checked });
    props.setTimer(event.target.checked)
  };

  function handleDrawerOpen() {
    setOpen(true);
  }

  function handleDrawerClose() {
    setOpen(false);
  }

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar style ={{backgroundImage: "linear-gradient(90deg, rgba(103,188,246,1) 0%, rgba(52,148,214,1) 29%, rgba(44,125,180,1) 65%, rgba(27,76,110,1) 100%)" }}
        position="absolute"
        className={clsx(classes.appBar, {
          [classes.appBarShift]: open,
        })}
      >

        <Toolbar style = {{minHeight:"48px"}}>
     
        <IconButton
            color="inherit"
            aria-label="Open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            className={clsx(classes.menuButton, {
              [classes.hide]: open,
            })}
          >
          <MenuIcon />
          </IconButton>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Typography variant="h6" noWrap style={{paddingTop:12}}>
                TDAS
              </Typography>
            </Grid>
          </Grid>
            <FeedBack />
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open,
        })}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          }),
        }}
        open={open}
      >
        <div className={classes.toolbar}>
          <Grid container spacing={2}>
            <Grid item xs={9} style={{textAlign: 'center'}}>
              <h2 style={{marginBottom:'0px'}}>THOTSAKAN</h2>
            </Grid>
            <Grid item xs={3}>
              <IconButton onClick={handleDrawerClose}>
                {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
              </IconButton>
            </Grid>
          </Grid>
        </div>
            <Profile />
        <div style={{height :"24px" ,backgroundColor:"#3598dc"}}></div>
        <List>
        <ExpansionPanel style={{margin:"0px"}}>
        <ExpansionPanelSummary style={{backgroundColor: "#4A525F" ,paddingLeft:"16px",minHeight: "32px"}}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography className={classes.heading}>
            Dispatcher
            </Typography>
        </ExpansionPanelSummary  >
        <ExpansionPanelDetails style={{backgroundColor: "#4A525F", paddingLeft:"8px" ,paddingBottom:"8px"}}  > 
        <Typography style = {{paddingLeft:"48px"}}>
          <Typography className = {classes.teamDispactherHeading} >
            Thotsakan
            </Typography>
            <Typography  className = {classes.teamDispactherContent}  >
              Pattamasiriwat,Krita
            </Typography>
            <Typography className = {classes.teamDispactherHeading} style={{marginTop:"12px"}}  >
            Supernova
            </Typography>
            <Typography  className = {classes.teamDispactherContent}  >
              Dikoko,Clement
            </Typography>
            <Typography className = {classes.teamDispactherHeading}  style={{marginTop:"12px"}}>
            Polaris
            </Typography>
            <Typography className = {classes.teamDispactherContent} >
              Johnson,Rick
            </Typography>
            <Typography className = {classes.teamDispactherHeading}  style={{marginTop:"12px",marginButtom:"12px",}} >
            Scrumblers
            </Typography>
            <Typography  className = {classes.teamDispactherContent}  >
              Karpenko,Claudio
            </Typography>
        </Typography>
        
        </ExpansionPanelDetails>
      </ExpansionPanel>
            
            <ListItem button key={"Thotsakan"}>
              <ListItemIcon><GroupIcon className={classes.svgThemeBlack} /></ListItemIcon>
              <ListItemText primary={"Thotsakan"} />
            </ListItem>
            <ListItem button key={"Scrumblers"}>
            <ListItemIcon><GroupIcon className={classes.svgThemeBlack} /></ListItemIcon>
              <ListItemText primary={"Scrumblers"} />
            </ListItem>
            <ListItem button key={"Supernova/Polaris"}>
            <ListItemIcon><GroupIcon className={classes.svgThemeBlack} /></ListItemIcon>
              <ListItemText primary={"Supernova/Polaris"} />
            </ListItem>

            <ListItem button key={"Global"}>
            <ListItemIcon><GroupIcon className={classes.svgThemeBlack} /></ListItemIcon>
              <ListItemText primary={"Global"} />
            </ListItem>

            <ListItem button key={'Others'}>
              <ListItemIcon>
                <GroupIcon className={classes.svgThemeBlack} />
              </ListItemIcon>
              <ListItemText primary={'Others'} />
            </ListItem>

		   <ListItem button key={"All"}>
            <ListItemIcon><GroupIcon className={classes.svgThemeBlack} /></ListItemIcon>
              <ListItemText primary={"All"} />
            </ListItem>
            
            <ExpansionPanel style={{margin:"0px"}}>
        <ExpansionPanelSummary style={{backgroundColor: "#4A525F" ,paddingLeft:"16px"}}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
            <SettingIcon style={{marginRight:"32px"}} className={classes.svgThemeBlack}/>
          <Typography className={classes.heading}>
            Setting
            </Typography>
        </ExpansionPanelSummary  >
        <ExpansionPanelDetails style={{backgroundColor: "#4A525F", paddingLeft:"8px" ,paddingBottom:"8px"}}  > 
        <FormControlLabel
        control={
          <Switch
            checked={state.checkedB}
            onChange={handleToggle('checkedB')}
            value="checkedB"
            color="Secondary"
          />
        }
        label="Auto Refesh"
        style = {{color:"white"}}
      />
                  <TextField 
                  id="standard-number"
                  label="Minute"
                  value={values.interval}
                  onChange={handleChange('interval')}
                  type="number"
                  className={classes.textField}
                  InputLabelProps={{
                    shrink: true,
                  }}
                  style = {{paddingBottom:"24px"}}
                />
        </ExpansionPanelDetails>
      </ExpansionPanel>
      <div style={{height :"24px" ,backgroundColor:"#3598dc" ,bottom:"0px"}}></div>
        </List>
  
      </Drawer>
      <main className={classes.content}>
        <div className={classes.toolbar} />
        {children}
      </main>
    </div>
  );
}
