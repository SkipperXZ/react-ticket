import React from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import FeedBackIcon from '@material-ui/icons/Feedback'
import IconButton from '@material-ui/core/IconButton';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
    container: {
      display: 'flex',
      flexWrap: 'wrap',
    }}));

export default function FormDialog() {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [values, setValues] = React.useState({
    feedback: '',
  });

  function handleClickOpen() {
    setOpen(true);
  }

  function handleClose() {
    setOpen(false);
  }
  function handleSend() {
    console.log(values.feedback)
    setOpen(false);
  }
  const handleChange = name => event => {
    setValues({ ...values, [name]: event.target.value });
  };


  return (
    <div>
       <IconButton onClick = {handleClickOpen} color="primary" caria-label="give feedback">
        <FeedBackIcon style={{color:"white"}}/>
        </IconButton>
      <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
        <DialogTitle id="form-dialog-title">Send Feedback</DialogTitle>
        <DialogContent>
        <DialogContentText style ={{color : "black"}} >
          <b>Tell us more about that </b>
          </DialogContentText>
          <DialogContentText>
           How can we make it better? We want to know everything you have to say, whether it's bad or good, suggestions or critics! We really need that in order to improve!.
          </DialogContentText>
          <TextField 
                   id="standard-multiline-static"
                   multiline
                   rows="6"
                   defaultValue=""
                   variant="outlined"
                   className={classes.textField}
                   value={values.feedback}
                   onChange={handleChange('feedback')}
                   margin="dense"
                   fullWidth
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleSend} color="primary">
            Send
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}