import React, { Component } from 'react'
import MUIDataTable from "./mTable/MUIDataTable";
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid'
import Typography from '@material-ui/core/Typography';
import incIcon from '../INC.png'
import woIcon from '../WO.png'
import lowIcon from "../Low.png"
import highIcon from "../High.png"
import mediumIcon from "../Medium.png"
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';

export default class Tables extends Component {
  constructor(props){
    super(props)

    this.state = {
      tickets : this.props.currentTickets,
      incidentFilter: [],
      unassignedFilter:[],
      workOrderFilter:[],
      jobFailureFilter:[]
    }
    this.handleIncident = this.handleIncident.bind(this)
    this.handleUnassigne =this.handleUnassigne.bind(this)
    this.handleWorkOrder = this.handleWorkOrder.bind(this)
    this.handleJobFailure =this.handleJobFailure.bind(this)
}
setZero(){
  this.setState({
    typeFilter: [],
    unassignedFilter: [],
    jobFailureFilter: []
  })
}
handleIncident(){
  this.setZero()
  this.setState({
    typeFilter: ['INCIDENT']
  })
}
handleUnassigne(){
  this.setZero()
  this.setState({
    unassignedFilter: ['Unassigned']
  })
}

handleWorkOrder(){
  this.setZero()
  this.setState({
    typeFilter: ['WORKORDER']
  })
}

handleJobFailure(){
  this.setZero()
  this.setState({
    jobFailureFilter: ['JOB FAILURE']
  })
}
  render() {
    const columns = [
      {
       name: "Ticket",
       label: "Ticket",
       options: {
        filterList: this.state.typeFilter,
        sort: true,
        filterOptions: {
          names: ["INCIDENT", "WORKORDER", "TASK"],
          logic(type, filters) {
            const show = (filters.indexOf("INCIDENT") >= 0 && type.includes("INC")) ||
              (filters.indexOf("WORKORDER") >= 0 && type.includes("WO")) ||
              (filters.indexOf("TASK") >= 0 && type.includes("TA"))
            const filtered = !show;
            return filtered;
          },
       
       },
       customBodyRender: (value, tableMeta, updateValue) => {
        return (
          <Typography>
          <Typography style={{fontSize:"16px"}}>
          {value}
          {(value.includes("INC"))?(<img src = {incIcon}  width = "36px" height = "32px" style = {{marginLeft: "10px"}}></img>)
          :(<img src = {woIcon} width = "36px" height = "32px" style = {{marginLeft: "10px"}} ></img>)}
        </Typography>
          <Typography style={{fontSize:"12px"}}>
          {this.props.currentTickets[tableMeta.rowIndex].Summary}
        </Typography>
        </Typography>
        );
      },
      }
    },
      {
       name: "Summary",
       label: "Summary",
       options: {
        filterList: this.state.jobFailureFilter,
        filterOptions: {
          names: ["JOB FAILURE"],
          logic(summary, filters) {
            const show = (filters.indexOf("JOB FAILURE") >= 0 && (summary.includes("UC4") || summary.toUpperCase().includes("Job Failure".toUpperCase()))) 
            const filtered = !show;
            return filtered;
          },
       },
       sort: true,
       display:false
      }
      },
      {
       name: "Status",
       label: "Status",
       options: {
        filter: true,
        sort: false,
        display : false,
       }
      },
      {
       name: "Customer",
       label: "Customer",
       options: {
        filter: false,
        sort: true,
        customBodyRender: (value, tableMeta, updateValue) => {
          return (
            <Typography>
            <Typography>
              {value}
          </Typography>
            <Typography style={{color:"#767676"}}>
            {this.props.currentTickets[tableMeta.rowIndex].Customer.Region}
          </Typography>
          </Typography>
          );
        },
       }
      },
      {
        name: "Region",
        label: "Region",
        options: {
          filterOptions: {
            names: ["AP", "NA", "EU","SA","AF"],
            logic(region, filters) {
              const show = (filters.indexOf("AP") >= 0 && region === "Asia Pacific" ) ||
                (filters.indexOf("NA") >= 0 && region === "North America") ||
                (filters.indexOf("EU") >= 0 && region === "Europe" ) ||
                (filters.indexOf("SA") >= 0 && region === "Central & South America") ||
                (filters.indexOf("AF") >= 0 && region === "Middle East / Africa" ) 
              const filtered = !show;
              return filtered;
            },
        },display : false,
      },
    },
    {
      name: "Assignee",
      label: "Assignee",
      options: {
        sort: true,
        filterList: this.state.unassignedFilter,
        /*filterOptions: {
          names: ["Unassigned"],
          logic(assignee, filters) {
            const show = (filters.indexOf("Unassigned") >= 0 && assignee==="Unassigned") 
            const filtered = !show;
            return filtered;
          },
      }*/
      filter:true
    }
     },
     {
      name: "Priority",
      label: "Priority",
      options: {
       filter: true,
       sort: true,
       customBodyRender: (value, tableMeta, updateValue) => {
         if(value === "High"){
          return(<img src = {highIcon}  width = "80px" height = "40px" align="middle"></img>)
         }else if(value ==="Medium"){
          return(<img src = {mediumIcon}  width = "80px" height = "40px" align="middle"></img>)
         }else if(value === "Low"){
          return(<img src = {lowIcon}  width = "80px" height = "40px" align="middle"></img>)

         }
        }
      }
     },
     {
      name: "Product",
      label: "Product",
      options: {
       filter: false,
       sort: false,
       display : false,
      }
     },

     {
      name: "Submitted Date",
      label: "Submitted Date",
      options: {
       filter: false,
       sort: true,
       customBodyRender: (value, tableMeta, updateValue) => {
        return (
        <Typography>
        <Typography>
        {new Date(value).toDateString()}
        </Typography>
        <Typography style={{color:"#767676"}}>
          {new Date(value).toLocaleTimeString()}
        </Typography>
        </Typography>
        );
        },
      }
     },
     {
      name: "Last Modified",
      label: "Last Modified",
      options: {
       filter: false,
       sort: true,
       sortDirection: 'desc',
       customBodyRender: (value, tableMeta, updateValue) => {
        return (
        <Typography>
          <Typography>
            {new Date(value).toDateString()}
          </Typography>
          <Typography style={{color:"#767676"}}>
            {new Date(value).toLocaleTimeString()}
          </Typography>
        </Typography>
        );
        },
      }
     },
     {
      name: "Notes",
      label: "Notes",
      options: {
       filter: false,
       sort: true,
       display : false,
      }
     },
    //  {
    //    name: 'Team',
    //    label: 'Team',
    //    options: {
    //      filter: false,
    //      sort: true
    //    }
    //  }
    
     ];
    let data =[]
    this.props.currentTickets.map((item,i)=>{
      data.push([item.Ticket_ID,
        item.Summary,
        item.Status,
        item.Customer.Name,
        item.Customer.Region,
        item.Assignee.Name ? item.Assignee.Name:"Unassigned",
        item.Priority,
        item.Product.Name,
        item.Submitted_On,
        item.Modified_On,
        item.Notes,
      ])
    })
    const options = {
      filterType: 'multiselect',
      /*onRowClick : (rowData, rowMeta)=>{
        var url = "http://itconsole/#/"+rowData[0].props.children[0].props.children[0]
        var win = window.open(url, '_blank');
        win.focus();
      },*/
      
      expandableRows:true,
      print: false,
      download: true,
      renderExpandableRow : (rowData, rowMeta) => {
        const colSpan = rowData.length + 1;
        return (
          <TableRow>
            <TableCell colSpan={colSpan}>
            {rowData[10] ?  rowData[10].split('\n').map( (it, i) => <Typography style={{fontSize : "14px"}} key={'x'+i}>{it}</Typography> ) : <Typography></Typography>}
  
            </TableCell>
          </TableRow>
        );
      }
    };
    return (
      <div>
      <Grid container spacing={3} style={{paddingTop:"20px",paddingBottom:"20px",margin:"0px"}}>
             <Button variant="contained"color="primary"onClick = {this.handleUnassigne}  style={{height:"70px",width:"200px",marginRight :"24px",fontSize:"20px",backgroundColor:"#65b5ec"}}>Unassgined</Button>
              <Button variant="contained"color="primary" onClick = {this.handleIncident}  style={{height:"70px",width:"200px",marginRight :"24px",fontSize:"20px",backgroundColor:"#4ea5e1"}} >Incidents</Button>
             <Button variant="contained"color="primary" onClick = {this.handleWorkOrder}  style={{height:"70px",width:"200px",marginRight :"24px",fontSize:"20px",backgroundColor:"#348fcd"}} >Work Orders</Button>
            <Button variant="contained"color="primary" onClick = {this.handleJobFailure}  style={{height:"70px",width:"200px",marginRight :"24px",fontSize:"20px",backgroundColor:"#3481b5"}} >Job Failures</Button>
        </Grid>
      <MUIDataTable 
          title={"Open Tickets"}
          data={data}
          columns={columns}
          options={options}
          updateTicket={this.props.updateTicket}
          currentState={this.props.currentState}
        />
      </div>

    )
  }
}
