import React, { Component } from 'react'
import MiniDrawer from '../components/Layout'
import Tables from '../components/Tables'
import Grid from '@material-ui/core/Grid'
import axios from 'axios'
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import Tab from '../components/Tab'
import MuiThemeProvider from "@material-ui/core/styles/MuiThemeProvider";
import { createMuiTheme } from "@material-ui/core/styles";

const theme = createMuiTheme({
    typography: {
      // Use the system font instead of the default Roboto font.
      fontFamily: [
        'Bahnschrift'
      ].join(','),
    },
  });
  

class Home extends Component {
    constructor(props){
        super(props)
       
        this.state = {
            thotsakanTickets : [],
            scrumblersTickets : [],
            superNovaPolarisTickets:[],
            otherTickets:[],
            currentTickets:[],
            currentState : 1,
            timer : {},
            isTimer: false,
            interval: 3,
        }
        this.setCurrentTickets = this.setCurrentTickets.bind(this);
        this.updateTicket = this.updateTicket.bind(this);
        this.setUpdateInterval = this.setUpdateInterval.bind(this);
        this.setTimer = this.setTimer.bind(this);
    }

    async setTimer(b){
        if(b){
            await this.setState({
                isTimer: true
            })
            this.setUpdateInterval(this.state.interval)
        }
        else{
            clearInterval(this.state.timer);
            this.setState({
                isTimer: false
            })
        }
    }

    async setUpdateInterval(interval){
   
        await this.setState({
            interval: interval
        })
        if(this.state.isTimer && interval != 0){
            clearInterval(this.state.timer);
            this.setState({
                timer : setInterval(this.updateTicket,interval*10000),
            })
        }
     
        
    }
    setCurrentTickets(ticket,state){
        this.setState({
            currentTickets : ticket
        })
        this.setState({
            currentState : state
        })
    }    
 

    componentDidMount(){
        var data = []
        var tempThot = []
        var tempSuper=[]
        var tempScrumbers=[]
        var tempOther=[]
        const url=""
        axios.get(url)
        .then(res => {
          data = res.data;
        })
        data.map((item,i)=>{
            if(item.team ==="Thotsakan"){
                tempThot.push(item)
            }else if(item.team ==="Supernova/Polaris"){
                tempSuper.push(item)
            }else if(item.team ==="Scrumbler"){
                tempScrumbers.push(item)
            }else{
                tempOther.push(item)
            }
        })
        this.setState({ thotsakanTickets : tempThot,
                        superNovaPolarisTickets: tempSuper,
                        scrumblersTickets : tempScrumbers,
                        otherTickets : tempOther    
                    });
        if(this.state.currentState === 1){
            this.setCurrentTickets(this.state.thotsakanTickets,1)
        }else if(this.state.currentState === 2){
            this.setCurrentTickets(this.state.scrumblersTickets,2)
        }else if(this.state.currentState === 3){
            this.setCurrentTickets(this.state.superNovaPolarisTickets,3)
        }else if(this.state.currentState === 4){
            this.setCurrentTickets(this.state.otherTickets,4)
        }
    }



    updateTicket(){
        var data =[]
        var tempThot = []
        var tempSuper=[]
        var tempScrumbers=[]
        var tempOther=[]
        const url=""
        axios.get(url)
        .then(res => {
          data = res.data;
        })

        console.log("update")
        this.setState({ thotsakanTickets : []});
        this.setState({ scrumblersTickets : []});
        this.setState({ superNovaPolarisTickets : []});
        this.setState({ otherTickets : []});
        this.setState({ currentTickets : []});

        data.map((item,i)=>{
            if(item.team ==="Thotsakan"){
                tempThot.push(item)
            }else if(item.team ==="Supernova/Polaris"){
                tempSuper.push(item)
            }else if(item.team ==="Scrumbler"){
                tempScrumbers.push(item)
            }else{
                tempOther.push(item)
            }
        })
        this.setState({ thotsakanTickets : tempThot,
                        superNovaPolarisTickets: tempSuper,
                        scrumblersTickets : tempScrumbers,
                        otherTickets : tempOther    
                    });
        if(this.state.currentState === 1){
            this.setCurrentTickets(this.state.thotsakanTickets,1)
        }else if(this.state.currentState === 2){
            this.setCurrentTickets(this.state.scrumblersTickets,2)
        }else if(this.state.currentState === 3){
            this.setCurrentTickets(this.state.superNovaPolarisTickets,3)
        }else if(this.state.currentState === 4){
            this.setCurrentTickets(this.state.otherTickets,4)
        }


        }

    render() {  
        return (
            <MuiThemeProvider theme={theme}>
            <MiniDrawer setUpdateInterval = {this.setUpdateInterval}
                        setTimer = {this.setTimer}>
                <Grid container spacing={2}>
                    <Grid item sm={12} style = {{paddingLeft:"72px",paddingRight:"72px"}}>
                        <Tab setCurrentTickets={this.setCurrentTickets} state = {this.state} />  
                        {  this.state.currentTickets.length == 0 ? (<CircularProgress disableShrink style ={{width :"100px" ,height :"100px",marginLeft :"720px",marginTop:"360px"}} />):(  <Tables  currentTickets={this.state.currentTickets}/>)}
                      
                    </Grid>
                </Grid>
            </MiniDrawer>
            </MuiThemeProvider>
        )
    }
}

export default Home