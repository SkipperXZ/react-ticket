import React, {Component} from 'react'
import Grid from '@material-ui/core/Grid'
import Typography from '@material-ui/core/Typography'
import { makeStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import thot from '../thot.png'


class Profile extends Component {
   
    render(){
        const avatar = {
              margin: 5,
              width: 60,
              height: 60,
            };
        const style = { 
            padding: '20px' 
        };
        return(
            <div className="profile-wrapper">
                <div style={style}>
                    <Grid container spacing={2}>
                        <Grid item sm={4}>
                        <Avatar alt="Remy Sharp" src={thot} style={avatar} />
                             </Grid>
                        <Grid item sm={8}> <Typography style={{fontSize:'18px'}}>ExxonMobil </Typography> </Grid>
                    </Grid>
                </div>
            </div>
        )
    }
}

export default Profile