import React, {Component} from 'react'
import Grid from '@material-ui/core/Grid'
import Typography from '@material-ui/core/Typography'
import axios from 'axios'
import Avatar from '@material-ui/core/Avatar';
import thot from '../thot.png'


class Profile extends Component {

    constructor(props){
        super(props)
        this.state = {
            person : {}
        }
    }


    componentDidMount() {
        axios.get(`https://ticket/api/user`, {withCredentials: true})
          .then(res => {
            const person = res.data;
            this.setState({ person });
          })
      }

    render(){
        const avatar = {
              margin: 5,
              width: 60,
              height: 60,
            };
        const style = { 
            padding: '20px' 
        };
        return(
            <div className="profile-wrapper">
                <div style={style}>
                    <Grid container spacing={2}>
                        <Grid item sm={4}>
                        <Avatar alt="Remy Sharp" src={thot} style={avatar} />
                             </Grid>
                        <Grid item sm={8}> 
                        <Typography style={{fontSize:'18px'}}>{this.state.person.Last_Name} </Typography>
                        <Typography style={{fontSize:'18px'}}>{this.state.person.First_Name} </Typography>
                         </Grid>
                    </Grid>
                </div>
            </div>
        )
    }
}

export default Profile